document.getElementById("changeColor").addEventListener("click", async () => {
    const color = document.getElementById("colorPicker").value;
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (tab) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (bgColor) => {
            document.body.style.backgroundColor = bgColor;
          },
          args: [color],
        });
      }
    });
  });
  